package com.example.project2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * The main entry point of the application.
 * This activity handles user authentication, allowing users to log in or create a new account.
 */
public class MainActivity extends AppCompatActivity {

    // Database helper for managing the SQLite database.
    private DatabaseHelper databaseHelper;

    // UI elements
    private TextInputEditText editTextUsername;
    private TextInputEditText editTextPassword;
    private TextInputLayout usernameLayout;
    private TextInputLayout passwordLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the database helper.
        databaseHelper = new DatabaseHelper(this);

        // Find and assign UI elements.
        usernameLayout = findViewById(R.id.username_layout);
        passwordLayout = findViewById(R.id.password_layout);
        editTextUsername = findViewById(R.id.username);
        editTextPassword = findViewById(R.id.password);
        MaterialButton buttonLogin = findViewById(R.id.login);
        MaterialButton buttonCreateAccount = findViewById(R.id.create_account);

        // Set click listeners for the buttons.
        buttonLogin.setOnClickListener(v -> handleLoginAttempt());
        buttonCreateAccount.setOnClickListener(v -> handleCreateAccountAttempt());
    }

    /**
     * Handles the click event for the "Create Account" button.
     * It validates the user input and attempts to create a new user account.
     */
    private void handleCreateAccountAttempt() {
        // Clear previous errors
        usernameLayout.setError(null);
        passwordLayout.setError(null);

        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Validate the input fields.
        if (!isInputValid(username, password)) {
            return;
        }

        // Attempt to add the user to the database.
        if (addUserToDatabase(username, password)) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
        } else {
            usernameLayout.setError("Username might already exist.");
        }
    }

    /**
     * Handles the click event for the "Login" button.
     * It validates the user input and attempts to log the user in.
     */
    private void handleLoginAttempt() {
        // Clear previous errors
        usernameLayout.setError(null);
        passwordLayout.setError(null);

        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Validate the input fields.
        if (!isInputValid(username, password)) {
            return;
        }

        // Check credentials against the database.
        if (checkUserCredentials(username, password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            // On successful login, navigate to the EventsActivity.
            Intent intent = new Intent(MainActivity.this, EventsActivity.class);
            startActivity(intent);
            // Finish MainActivity so the user cannot navigate back to it.
            finish();
        } else {
            passwordLayout.setError("Invalid username or password");
        }
    }

    /**
     * Validates that the username and password fields are not empty.
     * @param username The username entered by the user.
     * @param password The password entered by the user.
     * @return true if the input is valid, false otherwise.
     */
    private boolean isInputValid(String username, String password) {
        boolean isValid = true;
        if (TextUtils.isEmpty(username)) {
            usernameLayout.setError("Username is required");
            isValid = false;
        }
        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError("Password is required");
            isValid = false;
        }
        return isValid;
    }

    /**
     * Adds a new user to the 'users' table in the database.
     * @param username The username for the new account.
     * @param password The password for the new account.
     * @return true if the user was added successfully, false otherwise.
     */
    private boolean addUserToDatabase(String username, String password) {
        // Get a writable instance of the database.
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys.
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username); // Using updated convention
        values.put(DatabaseHelper.COLUMN_PASSWORD, password); // Note: In a real app, hash the password!

        // Insert the new row, returning the primary key value of the new row.
        long newRowId = db.insert(DatabaseHelper.TABLE_USERS, null, values);

        // A newRowId of -1 indicates an error, such as a duplicate username.
        return newRowId != -1;
    }

    /**
     * Checks if a user with the given credentials exists in the database.
     * @param username The username to check.
     * @param password The password to check.
     * @return true if the credentials are valid, false otherwise.
     */
    private boolean checkUserCredentials(String username, String password) {
        // Get a readable instance of the database.
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        // Define a projection that specifies which columns from the database will be used.
        String[] projection = { DatabaseHelper.COLUMN_ID };

        // Filter results WHERE "username" = ? AND "password" = ?
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };

        // Perform the query on the 'users' table.
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,   // The table to query
                projection,                   // The array of columns to return (pass null to get all)
                selection,                    // The columns for the WHERE clause
                selectionArgs,                // The values for the WHERE clause
                null,                         // don't group the rows
                null,                         // don't filter by row groups
                null                          // The sort order
        );

        // Check if the cursor found a matching row.
        boolean userExists = cursor.moveToFirst();

        // Close the cursor to release its resources.
        cursor.close();

        return userExists;
    }
}