package com.example.project2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * This activity manages the SMS permission for the application.
 * It explains why the permission is needed, allows the user to grant it, and displays the current status.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    // A constant to identify the SMS permission request.
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    // UI elements
    private TextView textViewPermissionStatus;
    private Button buttonGrantPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Find and assign UI elements.
        textViewPermissionStatus = findViewById(R.id.permission_status);
        buttonGrantPermission = findViewById(R.id.grant_sms_permission_button);

        // Set the initial permission status on the screen.
        updatePermissionStatusText();

        // Set a click listener for the grant permission button.
        buttonGrantPermission.setOnClickListener(v -> requestSmsPermission());
    }

    /**
     * Checks the current SMS permission status and updates the UI accordingly.
     */
    private void updatePermissionStatusText() {
        // Check if the SEND_SMS permission has been granted.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // If permission is granted, update the text and disable the button.
            textViewPermissionStatus.setText(R.string.permission_status_granted);
            buttonGrantPermission.setEnabled(false);
        } else {
            // If permission is denied, update the text and enable the button.
            textViewPermissionStatus.setText(R.string.permission_status_denied);
            buttonGrantPermission.setEnabled(true);
        }
    }

    /**
     * Requests the SEND_SMS permission from the user if it has not already been granted.
     */
    private void requestSmsPermission() {
        // Check if the permission is not already granted.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request the permission from the user.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    /**
     * Callback for the result from requesting permissions.
     * @param requestCode The request code passed in requestPermissions().
     * @param permissions The requested permissions.
     * @param grantResults The grant results for the corresponding permissions.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Check if the result corresponds to our SMS permission request.
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            // Update the UI based on the user's response.
            updatePermissionStatusText();
        }
    }
}