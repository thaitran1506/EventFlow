package com.example.project2;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/**
 * A BroadcastReceiver that triggers at the time of a scheduled event.
 * It sends an SMS notification to the user if the app has the required permissions.
 */
public class EventNotificationReceiver extends BroadcastReceiver {

    // A placeholder phone number for sending the SMS notification.
    // In a real application, this would be a user-configurable setting.
    private static final String DESTINATION_PHONE_NUMBER = "555-555-5555";

    /**
     * This method is called when the BroadcastReceiver is receiving an Intent broadcast.
     * @param context The Context in which the receiver is running.
     * @param intent The Intent being received.
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        // Retrieve the event details from the Intent.
        String eventName = intent.getStringExtra("event_name");
        String eventDate = intent.getStringExtra("event_date");

        // Check if the app has permission to send SMS messages.
        if (hasSmsPermission(context)) {
            // If permission is granted, attempt to send the SMS.
            sendSmsNotification(context, eventName, eventDate);
        } else {
            // If permission is not granted, show a toast message to inform the user.
            Toast.makeText(context, "SMS permission not granted. Cannot send notification.", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Checks if the app has been granted the SEND_SMS permission.
     * @param context The context to use for checking permissions.
     * @return true if the permission is granted, false otherwise.
     */
    private boolean hasSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Sends an SMS notification with the event details.
     * @param context The context to use for sending the SMS.
     * @param eventName The name of the event.
     * @param eventDate The date and time of the event.
     */
    private void sendSmsNotification(Context context, String eventName, String eventDate) {
        try {
            // Get the default instance of SmsManager.
            SmsManager smsManager = SmsManager.getDefault();

            // Construct the SMS message body.
            String message = "Reminder: Your event '" + eventName + "' is scheduled for " + eventDate + ".";

            // Send the SMS message.
            smsManager.sendTextMessage(DESTINATION_PHONE_NUMBER, null, message, null, null);

            // Show a confirmation toast.
            Toast.makeText(context, "Event reminder SMS sent.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // If sending fails, show an error toast and log the exception.
            Toast.makeText(context, "Failed to send SMS.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}