package com.example.project2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * This activity displays a list of upcoming events to the user.
 * It allows users to view, delete, and add new events.
 */
public class EventsActivity extends AppCompatActivity implements EventAdapter.OnDeleteClickListener {

    // Database helper for managing the SQLite database.
    private DatabaseHelper databaseHelper;

    // List to hold the events retrieved from the database.
    private final List<Event> eventList = new ArrayList<>();

    // Adapter for the RecyclerView that displays the events.
    private EventAdapter eventAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        // Set up the toolbar.
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize the database helper.
        databaseHelper = new DatabaseHelper(this);

        // Set up the RecyclerView.
        RecyclerView recyclerViewEvents = findViewById(R.id.events_grid);
        eventAdapter = new EventAdapter(eventList, this);
        recyclerViewEvents.setAdapter(eventAdapter);

        // Set up the FloatingActionButton for adding new events.
        FloatingActionButton fabAddEvent = findViewById(R.id.add_event_fab);
        fabAddEvent.setOnClickListener(v -> {
            // Launch the AddEventActivity to create a new event.
            Intent intent = new Intent(EventsActivity.this, AddEventActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload the events from the database every time the activity is resumed.
        loadEventsFromDatabase();
    }

    /**
     * Loads all events from the 'events' table in the database and updates the RecyclerView.
     */
    private void loadEventsFromDatabase() {
        // Clear the existing list to avoid duplicates.
        eventList.clear();

        // Get a readable instance of the database.
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        // Define the columns to retrieve.
        String[] projection = {
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_EVENT_NAME,
                DatabaseHelper.COLUMN_EVENT_DATE,
                DatabaseHelper.COLUMN_EVENT_INFO
        };

        // Query the database for all events.
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_EVENTS,
                projection,
                null, null, null, null, null
        );

        // Iterate through the cursor and create Event objects.
        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));
            String info = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_INFO));
            eventList.add(new Event(id, name, date, info));
        }

        // Close the cursor to release resources.
        cursor.close();

        // Notify the adapter that the data set has changed.
        eventAdapter.notifyDataSetChanged();
    }

    /**
     * Handles the click event for the delete button on an event item.
     * @param event The event to be deleted.
     */
    @Override
    public void onDeleteClick(Event event) {
        // Get a writable instance of the database.
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // Define the selection criteria (which row to delete).
        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = {String.valueOf(event.getId())};

        // Execute the delete operation.
        int deletedRows = db.delete(DatabaseHelper.TABLE_EVENTS, selection, selectionArgs);

        // Show a toast message indicating success or failure.
        if (deletedRows > 0) {
            Toast.makeText(this, "Event deleted successfully", Toast.LENGTH_SHORT).show();
            // Reload the events to reflect the deletion.
            loadEventsFromDatabase();
        } else {
            Toast.makeText(this, "Error deleting event", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Inflates the options menu from the menu resource file.
     * @param menu The options menu in which to place items.
     * @return true for the menu to be displayed; false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.events_menu, menu);
        return true;
    }

    /**
     * Handles clicks on the options menu items.
     * @param item The menu item that was selected.
     * @return true to consume the event here; false to allow normal menu processing to proceed.
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle the "SMS Permission" menu item click.
        if (item.getItemId() == R.id.action_sms_permission) {
            // Launch the SmsPermissionActivity.
            Intent intent = new Intent(this, SmsPermissionActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}