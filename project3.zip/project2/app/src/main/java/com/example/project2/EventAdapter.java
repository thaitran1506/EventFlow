package com.example.project2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter to bind a list of events to a RecyclerView.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    // The list of events to be displayed.
    private final List<Event> eventList;

    // Listener for delete button clicks.
    private final OnDeleteClickListener onDeleteClickListener;

    /**
     * Interface for handling delete button clicks.
     */
    public interface OnDeleteClickListener {
        void onDeleteClick(Event event);
    }

    /**
     * Constructor for the EventAdapter.
     * @param eventList The list of events to display.
     * @param onDeleteClickListener The listener for delete clicks.
     */
    public EventAdapter(List<Event> eventList, OnDeleteClickListener onDeleteClickListener) {
        this.eventList = eventList;
        this.onDeleteClickListener = onDeleteClickListener;
    }

    /**
     * Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
     * @param parent The ViewGroup into which the new View will be added after it is bound to an adapter position.
     * @param viewType The view type of the new View.
     * @return A new EventViewHolder that holds a View of the given view type.
     */
    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for a single event item.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * @param holder The ViewHolder which should be updated to represent the contents of the item at the given position.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Get the event at the current position.
        Event currentEvent = eventList.get(position);

        // Bind the event data to the ViewHolder's views.
        holder.bind(currentEvent, onDeleteClickListener);
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return eventList.size();
    }

    /**
     * A ViewHolder describes an item view and metadata about its place within the RecyclerView.
     */
    static class EventViewHolder extends RecyclerView.ViewHolder {
        // UI elements for a single event item.
        private final TextView textViewEventName;
        private final TextView textViewEventDate;
        private final ImageButton buttonDeleteEvent;

        /**
         * Constructor for the EventViewHolder.
         * @param itemView The view for a single event item.
         */
        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            // Find and assign UI elements.
            textViewEventName = itemView.findViewById(R.id.event_name);
            textViewEventDate = itemView.findViewById(R.id.event_date);
            buttonDeleteEvent = itemView.findViewById(R.id.delete_event_button);
        }

        /**
         * Binds an event's data to the views and sets the click listener for the delete button.
         * @param event The event to be displayed.
         * @param listener The listener for the delete button.
         */
        public void bind(final Event event, final OnDeleteClickListener listener) {
            textViewEventName.setText(event.getName());
            textViewEventDate.setText(event.getDate());
            buttonDeleteEvent.setOnClickListener(v -> listener.onDeleteClick(event));
        }
    }
}