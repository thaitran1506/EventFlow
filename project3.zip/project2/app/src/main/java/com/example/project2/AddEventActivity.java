package com.example.project2;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * This activity allows users to add a new event to the database.
 * It provides fields for the event name, time, and additional information.
 */
public class AddEventActivity extends AppCompatActivity {

    // Database helper for managing the SQLite database.
    private DatabaseHelper databaseHelper;

    // UI elements for event input.
    private TextInputEditText editTextEventName;
    private TextInputEditText editTextEventTime;
    private TextInputEditText editTextEventInfo;

    private Calendar selectedDateTime = Calendar.getInstance();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialize the database helper.
        databaseHelper = new DatabaseHelper(this);

        // Find and assign UI elements.
        editTextEventName = findViewById(R.id.event_name_input);
        editTextEventTime = findViewById(R.id.event_time_input);
        editTextEventInfo = findViewById(R.id.event_info_input);
        MaterialButton buttonSaveEvent = findViewById(R.id.save_event_button);
        MaterialButton buttonCancel = findViewById(R.id.cancel_button);

        // Make the event time EditText non-focusable to show the picker on click.
        editTextEventTime.setFocusable(false);
        editTextEventTime.setOnClickListener(v -> showDateTimePicker());

        // Set a click listener for the save button.
        buttonSaveEvent.setOnClickListener(v -> handleSaveEvent());
        buttonCancel.setOnClickListener(v -> finish());
    }

    private void showDateTimePicker() {
        // Get the current date for the DatePickerDialog.
        final Calendar currentDate = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedDateTime.set(Calendar.YEAR, year);
            selectedDateTime.set(Calendar.MONTH, month);
            selectedDateTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            // After setting the date, show the TimePickerDialog.
            new TimePickerDialog(this, (timeView, hourOfDay, minute) -> {
                selectedDateTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selectedDateTime.set(Calendar.MINUTE, minute);

                // Format and display the selected date and time.
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.getDefault());
                editTextEventTime.setText(sdf.format(selectedDateTime.getTime()));
            }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), false).show();
        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DATE)).show();
    }

    /**
     * Handles the click event for the "Save Event" button.
     * It validates user input, saves the event to the database, and schedules a notification.
     */
    private void handleSaveEvent() {
        String eventName = editTextEventName.getText().toString().trim();
        String eventTime = editTextEventTime.getText().toString().trim();
        String eventInfo = editTextEventInfo.getText().toString().trim();

        // Validate that the event name and time are not empty.
        if (TextUtils.isEmpty(eventName) || TextUtils.isEmpty(eventTime)) {
            Toast.makeText(this, "Please enter the event name and time", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert the event into the database and get its ID.
        long newRowId = addEventToDatabase(eventName, eventTime, eventInfo);

        // If the event was saved successfully, schedule a notification and close the activity.
        if (newRowId != -1) {
            Toast.makeText(this, "Event saved successfully", Toast.LENGTH_SHORT).show();
            // Use the row ID as a unique ID for the notification.
            scheduleSmsNotification(eventName, eventTime, (int) newRowId);
            // Return to the previous screen.
            finish();
        } else {
            Toast.makeText(this, "Error saving the event", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Inserts a new event into the 'events' table in the database.
     * @param name The name of the event.
     * @param time The time of the event.
     * @param info Additional information about the event.
     * @return The ID of the newly inserted row, or -1 if an error occurred.
     */
    private long addEventToDatabase(String name, String time, String info) {
        // Get a writable instance of the database.
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys.
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_EVENT_NAME, name);
        values.put(DatabaseHelper.COLUMN_EVENT_DATE, time);
        values.put(DatabaseHelper.COLUMN_EVENT_INFO, info);

        // Insert the new row.
        return db.insert(DatabaseHelper.TABLE_EVENTS, null, values);
    }

    /**
     * Schedules an SMS notification to be sent at the time of the event.
     * @param eventName The name of the event.
     * @param eventDate The date and time of the event in "MM/dd/yyyy HH:mm" format.
     * @param notificationId A unique ID for the notification.
     */
    private void scheduleSmsNotification(String eventName, String eventDate, int notificationId) {
        // Create an intent that will be broadcast to the EventNotificationReceiver.
        Intent intent = new Intent(this, EventNotificationReceiver.class);
        intent.putExtra("event_name", eventName);
        intent.putExtra("event_date", eventDate);

        // Create a PendingIntent that will be triggered at the time of the event.
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, notificationId, intent,
                // FLAG_UPDATE_CURRENT ensures that if the user edits the event, the new time is used.
                // FLAG_IMMUTABLE is required for PendingIntents on newer Android versions.
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Get an instance of the AlarmManager.
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        // Parse the date string to get the trigger time in milliseconds.
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.getDefault());
        try {
            Date date = sdf.parse(eventDate);
            if (date != null) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date);

                // Only schedule the alarm if the event is in the future.
                if (calendar.getTimeInMillis() > System.currentTimeMillis()) {
                    // Schedule the alarm to wake up the device and send the broadcast.
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                    Toast.makeText(this, "Notification scheduled for " + eventDate, Toast.LENGTH_SHORT).show();
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
            // Inform the user if the date format is incorrect.
            Toast.makeText(this, "Invalid date format. Please use MM/dd/yyyy HH:mm", Toast.LENGTH_LONG).show();
        }
    }
}